﻿using System;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Drawing;

namespace SteamGameEmulator
{
    class Program
    {
        private static uint GAME_APPID = 730;
        private static readonly string ConfigFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "appid.txt");
        private static readonly string Title = "Steam Game Emulator";

        // Для переподключения
        private static System.Timers.Timer _reconnectTimer;
        private static int _reconnectAttempts = 0;
        private static readonly int MAX_RECONNECT_ATTEMPTS = 10;

        // Для настройки окна при старте
        private static readonly string WindowConfigFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "window.txt");
        private static bool _startMinimized = false;

        // Для подсчета времени
        private static DateTime _startTime;
        private static bool _isRunning = false;

        // Импорты для работы с окном консоли и сообщениями
        [DllImport("kernel32.dll")]
        private static extern IntPtr GetConsoleWindow();

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern bool BringWindowToTop(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern bool PeekMessage(out MSG msg, IntPtr hWnd, uint wMsgFilterMin, uint wMsgFilterMax, uint wRemoveMsg);

        [DllImport("user32.dll")]
        private static extern bool TranslateMessage(ref MSG msg);

        [DllImport("user32.dll")]
        private static extern IntPtr DispatchMessage(ref MSG msg);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetStdHandle(int nStdHandle);

        [DllImport("kernel32.dll")]
        private static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);

        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);

        [StructLayout(LayoutKind.Sequential)]
        private struct MSG
        {
            public IntPtr hwnd;
            public uint message;
            public IntPtr wParam;
            public IntPtr lParam;
            public uint time;
            public int pt_x;
            public int pt_y;
        }

        private const int SW_HIDE = 0;
        private const int SW_SHOW = 5;
        private const int SW_RESTORE = 9;
        private const int SW_SHOWNORMAL = 1;
        private const uint PM_REMOVE = 0x0001;
        private const int STD_INPUT_HANDLE = -10;
        private const uint ENABLE_WINDOW_INPUT = 0x0008;

        private static readonly IntPtr HWND_TOP = new IntPtr(0);
        private const uint SWP_NOSIZE = 0x0001;
        private const uint SWP_NOMOVE = 0x0002;
        private const uint SWP_SHOWWINDOW = 0x0040;

        // Нативные функции Windows для Steam
        private struct Native
        {
            [DllImport("kernel32.dll", SetLastError = true, BestFitMapping = false, ThrowOnUnmappableChar = true)]
            internal static extern IntPtr GetProcAddress(IntPtr module, string name);

            [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
            internal static extern IntPtr LoadLibraryEx(string path, IntPtr file, uint flags);

            [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
            [return: MarshalAs(UnmanagedType.Bool)]
            internal static extern bool SetDllDirectory(string path);

            internal const uint LOAD_WITH_ALTERED_SEARCH_PATH = 8;
        }

        // Делегаты для функций Steam
        [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
        private delegate IntPtr CreateInterfaceDelegate(string version, IntPtr returnCode);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        [return: MarshalAs(UnmanagedType.I1)]
        private delegate bool SteamGetCallbackDelegate(int pipe, out CallbackMessage message, out int call);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        [return: MarshalAs(UnmanagedType.I1)]
        private delegate bool SteamFreeLastCallbackDelegate(int pipe);

        // Структура сообщения колбэка
        [StructLayout(LayoutKind.Explicit, Size = 8)]
        public struct CallbackMessage
        {
            [FieldOffset(0)]
            public int Id;
            [FieldOffset(4)]
            public int Flags;
            [FieldOffset(8)]
            public IntPtr ParamPointer;
            [FieldOffset(12)]
            public int ParamCount;
        }

        // Класс для доступа к виртуальной таблице
        [StructLayout(LayoutKind.Sequential)]
        private class NativeClass
        {
            public IntPtr VirtualTable;
        }

        private static void LoadWindowConfig()
        {
            try
            {
                if (File.Exists(WindowConfigFile))
                {
                    string content = File.ReadAllText(WindowConfigFile).Trim().ToLower();
                    _startMinimized = content == "minimized" || content == "hide" || content == "hidden";
                }
            }
            catch (Exception ex)
            {
                // Игнорируем ошибки
            }
        }


        // Функции SteamClient
        [StructLayout(LayoutKind.Sequential)]

        private struct SteamClientFunctions
        {
            public IntPtr CreateSteamPipe;
            public IntPtr ReleaseSteamPipe;
            public IntPtr ConnectToGlobalUser;
            public IntPtr ReleaseUser;
            public IntPtr GetISteamUser;
            public IntPtr GetISteamGameServer;
            public IntPtr SetLocalIPBinding;
            public IntPtr GetISteamFriends;
            public IntPtr GetISteamUtils;
            public IntPtr GetISteamBilling;
            public IntPtr GetISteamMatchmaking;
            public IntPtr GetISteamMasterServerUpdater;
            public IntPtr GetISteamMatchmakingServers;
            public IntPtr GetISteamGenericInterface;
            public IntPtr GetISteamApps;
            public IntPtr GetISteamContentServer;
            public IntPtr GetISteamUGC;
            public IntPtr GetISteamAppList;
        }

        // Глобальные переменные Steam
        private static IntPtr _steamModule = IntPtr.Zero;
        private static CreateInterfaceDelegate _createInterface;
        private static SteamGetCallbackDelegate _getCallback;
        private static SteamFreeLastCallbackDelegate _freeLastCallback;
        private static int _pipe;
        private static int _user;
        private static IntPtr _steamClient;
        private static bool _steamRunning = false;
        private static SteamClientFunctions _steamFunctions;
        private static Thread _steamThread;
        private static bool _stopSteam = false;
        private static readonly object _steamLock = new object();

        // Для трея
        private static NotifyIcon _trayIcon;
        private static ContextMenuStrip _trayMenu;
        private static IntPtr _consoleWindow;
        private static bool _isHidden = false;

        // Для неблокирующего чтения консоли
        private static string _inputBuffer = "";

        [STAThread]
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            _consoleWindow = GetConsoleWindow();

            // Устанавливаем заголовок окна
            Console.Title = Title;

            // Загружаем AppID из файла
            LoadAppId();

            // Загружаем настройку окна
            LoadWindowConfig();

            // Включаем режим окна для консоли
            IntPtr hStdin = GetStdHandle(STD_INPUT_HANDLE);
            GetConsoleMode(hStdin, out uint mode);
            SetConsoleMode(hStdin, mode | ENABLE_WINDOW_INPUT);

            // Применяем настройку окна
            if (_startMinimized)
            {
                ShowWindow(_consoleWindow, SW_HIDE);
                _isHidden = true;
            }
            else
            {
                ShowWindow(_consoleWindow, SW_SHOWNORMAL);
                SetForegroundWindow(_consoleWindow);
                _isHidden = false;
            }

            DrawHeader();
            DrawStatus();

            // Создаем иконку в трее
            CreateTrayIcon();

            // Автоматически запускаем Steam при старте
            StartSteam();

            // Запоминаем время старта
            _startTime = DateTime.Now;
            _isRunning = true;

            // Главный цикл - только обработка сообщений трея и консоли
            while (true)
            {
                // Обрабатываем сообщения трея - только одно сообщение за цикл
                MSG msg;
                if (PeekMessage(out msg, IntPtr.Zero, 0, 0, PM_REMOVE))
                {
                    TranslateMessage(ref msg);
                    DispatchMessage(ref msg);
                }

                // Неблокирующее чтение консоли (только если окно видимо)
                if (!_isHidden && Console.KeyAvailable)
                {
                    ConsoleKeyInfo key = Console.ReadKey(intercept: true);

                    if (key.Key == ConsoleKey.Enter)
                    {
                        Console.WriteLine();
                        ProcessCommand(_inputBuffer);
                        _inputBuffer = "";
                    }
                    else if (key.Key == ConsoleKey.Backspace)
                    {
                        if (_inputBuffer.Length > 0)
                        {
                            _inputBuffer = _inputBuffer.Substring(0, _inputBuffer.Length - 1);
                            Console.Write("\b \b");
                        }
                    }
                    else if (!char.IsControl(key.KeyChar))
                    {
                        _inputBuffer += key.KeyChar;
                        Console.Write(key.KeyChar);
                    }
                }

                // Небольшая задержка для снижения нагрузки
                Thread.Sleep(10);
            }
        }

        private static void DrawHeader()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("STEAM GAME EMULATOR");
            Console.ResetColor();
            Console.WriteLine();
        }

        private static void DrawStatus()
        {
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("STEAM GAME EMULATOR");
            Console.ResetColor();
            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("Config:         " + ConfigFile);
            Console.WriteLine("Window config:  " + WindowConfigFile);
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Current AppID:  " + GAME_APPID);
            Console.WriteLine("Start mode:     " + (_startMinimized ? "Minimized to tray" : "Normal window"));
            Console.ResetColor();
            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Available Commands:");
            Console.ResetColor();
            Console.WriteLine("  hide     - Hide to tray");
            Console.WriteLine("  quit     - Exit");
            Console.WriteLine("  appid X  - Change game ID (example: appid 730)");
            Console.WriteLine("  time     - Show current uptime");
            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("Booster is running automatically");
            Console.WriteLine("Auto-reconnect every 1 minute if connection fails");
            Console.ResetColor();
            Console.WriteLine();

            if (_steamRunning)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Steam connected for AppID: " + GAME_APPID);
                Console.ResetColor();
            }
        }

        private static void LoadAppId()
        {
            try
            {
                if (File.Exists(ConfigFile))
                {
                    string content = File.ReadAllText(ConfigFile).Trim();
                    if (uint.TryParse(content, out uint savedAppId))
                    {
                        GAME_APPID = savedAppId;
                    }
                }
                else
                {
                    File.WriteAllText(ConfigFile, GAME_APPID.ToString());
                }
            }
            catch (Exception ex)
            {
                // Игнорируем ошибки
            }
        }

        private static void SaveAppId()
        {
            try
            {
                File.WriteAllText(ConfigFile, GAME_APPID.ToString());
            }
            catch { }
        }

        private static void ProcessCommand(string input)
        {
            input = input.Trim().ToLower();

            if (input == "hide")
            {
                HideToTray();
                Console.ResetColor();
                Console.Write("> ");
            }
            else if (input == "quit")
            {
                _reconnectTimer?.Stop();
                _reconnectTimer?.Dispose();
                _trayIcon.Visible = false;
                _trayIcon.Dispose();
                Environment.Exit(0);
            }
            else if (input == "time")
            {
                TimeSpan elapsed = DateTime.Now - _startTime;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"Uptime: {elapsed:hh\\:mm\\:ss}");
                Console.ResetColor();
                Console.Write("> ");

            }
            else if (input?.StartsWith("appid") == true)
            {
                var parts = input.Split(' ');
                if (parts.Length == 2 && uint.TryParse(parts[1], out uint newAppId))
                {
                    GAME_APPID = newAppId;
                    SaveAppId();

                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"AppID changed to: {GAME_APPID} (saved)");
                    Console.WriteLine("Restart the program to apply");
                    Console.ResetColor();
                    Console.Write("> ");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"Current AppID: {GAME_APPID}");
                    Console.ResetColor();
                    Console.Write("> ");
                }
            }
        }

        private static void CreateTrayIcon()
        {
            _trayMenu = new ContextMenuStrip();
            _trayMenu.ShowImageMargin = false;

            var showItem = new ToolStripMenuItem("Show window");
            showItem.Click += (s, e) => ShowFromTray();

            var hideItem = new ToolStripMenuItem("Hide window");
            hideItem.Click += (s, e) => HideToTray();

            var separator = new ToolStripSeparator();

            var exitItem = new ToolStripMenuItem("Exit");
            exitItem.Click += (s, e) => {
                _reconnectTimer?.Stop();
                _reconnectTimer?.Dispose();
                _trayIcon.Visible = false;
                _trayIcon.Dispose();
                Environment.Exit(0);
            };

            _trayMenu.Items.Add(showItem);
            _trayMenu.Items.Add(hideItem);
            _trayMenu.Items.Add(separator);
            _trayMenu.Items.Add(exitItem);

            _trayIcon = new NotifyIcon();

            // Создаем круглую иконку с молнией
            using (Bitmap bitmap = new Bitmap(16, 16))
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.Clear(Color.Transparent);

                // Синий круг
                using (Brush brush = new SolidBrush(Color.FromArgb(0, 120, 215)))
                {
                    g.FillEllipse(brush, 0, 0, 15, 15);
                }

                // Белая молния
                using (Pen pen = new Pen(Color.White, 2))
                {
                    g.DrawLine(pen, 8, 3, 5, 8);
                    g.DrawLine(pen, 5, 8, 10, 8);
                    g.DrawLine(pen, 10, 8, 7, 13);
                }

                IntPtr hIcon = bitmap.GetHicon();
                _trayIcon.Icon = Icon.FromHandle(hIcon);
            }

            _trayIcon.Text = "Steam Game Emulator";
            _trayIcon.ContextMenuStrip = _trayMenu;
            _trayIcon.Visible = true;

            _trayIcon.MouseClick += (s, e) => {
                if (e.Button == MouseButtons.Left)
                {
                    if (_isHidden)
                        ShowFromTray();
                    else
                        HideToTray();
                }
                else if (e.Button == MouseButtons.Right)
                {
                    _trayMenu.Show(Cursor.Position);
                }
            };

            _trayIcon.DoubleClick += (s, e) => {
                if (_isHidden)
                    ShowFromTray();
                else
                    HideToTray();
            };
        }

        private static void ProcessCallbacks()
        {
            if (_pipe == 0) return;

            // Обрабатываем только один колбэк за раз
            CallbackMessage message;
            int call;
            if (GetCallback(out message, out call))
            {
                FreeLastCallback();
            }
        }

        private static void StartSteam()
        {
            lock (_steamLock)
            {
                if (_steamRunning) return;
                _stopSteam = false;
            }

            _steamThread = new Thread(() => {
                try
                {
                    string installPath = GetSteamInstallPath();
                    if (string.IsNullOrEmpty(installPath))
                        installPath = @"C:\Program Files (x86)\Steam";

                    Environment.SetEnvironmentVariable("SteamAppId", GAME_APPID.ToString());

                    if (!LoadSteamClient(installPath))
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Failed to load Steam client");
                        Console.ResetColor();
                        ScheduleReconnect();
                        return;
                    }

                    _steamClient = _createInterface("SteamClient008", IntPtr.Zero);
                    if (_steamClient == IntPtr.Zero)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Failed to create Steam client");
                        Console.ResetColor();
                        ScheduleReconnect();
                        return;
                    }

                    var nativeClass = Marshal.PtrToStructure<NativeClass>(_steamClient);
                    _steamFunctions = Marshal.PtrToStructure<SteamClientFunctions>(nativeClass.VirtualTable);

                    var createPipe = Marshal.GetDelegateForFunctionPointer<CreateSteamPipeDelegate>(_steamFunctions.CreateSteamPipe);
                    _pipe = createPipe(_steamClient);
                    if (_pipe == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Failed to create pipe");
                        Console.ResetColor();
                        ScheduleReconnect();
                        return;
                    }

                    var connectToUser = Marshal.GetDelegateForFunctionPointer<ConnectToGlobalUserDelegate>(_steamFunctions.ConnectToGlobalUser);
                    _user = connectToUser(_steamClient, _pipe);
                    if (_user == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Failed to connect to user");
                        Console.ResetColor();
                        try
                        {
                            if (_steamFunctions.ReleaseSteamPipe != IntPtr.Zero)
                            {
                                var releasePipe = Marshal.GetDelegateForFunctionPointer<ReleaseSteamPipeDelegate>(_steamFunctions.ReleaseSteamPipe);
                                releasePipe(_steamClient, _pipe);
                            }
                        }
                        catch { }
                        _pipe = 0;
                        ScheduleReconnect();
                        return;
                    }

                    lock (_steamLock)
                    {
                        _steamRunning = true;
                        _reconnectAttempts = 0;
                    }

                    // УСПЕШНОЕ ПОДКЛЮЧЕНИЕ - ПИШЕМ СРАЗУ ЗЕЛЕНЫМ
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Steam connected for AppID: {GAME_APPID}");
                    Console.ResetColor();
                    Console.Write("> ");

                    // Основной цикл с большой задержкой для минимальной нагрузки
                    while (!_stopSteam)
                    {
                        try
                        {
                            ProcessCallbacks();
                        }
                        catch { }

                        // Спим 2 секунды между проверками - этого достаточно
                        Thread.Sleep(2000);
                    }
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Steam error: {ex.Message}");
                    Console.ResetColor();
                    ScheduleReconnect();
                }
                finally
                {
                    lock (_steamLock)
                    {
                        _steamRunning = false;
                    }
                }
            });

            _steamThread.IsBackground = true;
            _steamThread.Start();
        }

        private static void ScheduleReconnect()
        {
            lock (_steamLock)
            {
                if (_reconnectAttempts >= MAX_RECONNECT_ATTEMPTS)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Failed to connect after {MAX_RECONNECT_ATTEMPTS} attempts. Stopping reconnection.");
                    Console.ResetColor();
                    return;
                }

                _reconnectAttempts++;
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"Reconnection attempt {_reconnectAttempts}/{MAX_RECONNECT_ATTEMPTS} in 1 minute...");
            Console.ResetColor();

            // Создаем таймер для переподключения
            _reconnectTimer = new System.Timers.Timer(60000); // 60 секунд
            _reconnectTimer.AutoReset = false;
            _reconnectTimer.Elapsed += (s, e) => {
                _reconnectTimer?.Dispose();
                _reconnectTimer = null;

                if (!_steamRunning && _reconnectAttempts < MAX_RECONNECT_ATTEMPTS)
                {
                    Console.WriteLine("Attempting to reconnect...");
                    StartSteam();
                }
            };
            _reconnectTimer.Start();
        }

        private static string GetSteamInstallPath()
        {
            try
            {
                string path = Registry.GetValue(@"HKEY_LOCAL_MACHINE\Software\Valve\Steam", "InstallPath", null) as string;
                if (!string.IsNullOrEmpty(path))
                    return path;

                path = Registry.GetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath", null) as string;
                return path;
            }
            catch
            {
                return null;
            }
        }

        private static bool LoadSteamClient(string path)
        {
            try
            {
                Native.SetDllDirectory(path + ";" + Path.Combine(path, "bin"));

                string clientPath = Path.Combine(path, "steamclient.dll");
                if (!File.Exists(clientPath))
                {
                    return false;
                }

                IntPtr module = Native.LoadLibraryEx(clientPath, IntPtr.Zero, Native.LOAD_WITH_ALTERED_SEARCH_PATH);
                if (module == IntPtr.Zero)
                {
                    return false;
                }

                _createInterface = GetExportFunction<CreateInterfaceDelegate>(module, "CreateInterface");
                if (_createInterface == null)
                {
                    return false;
                }

                _getCallback = GetExportFunction<SteamGetCallbackDelegate>(module, "Steam_BGetCallback");
                if (_getCallback == null)
                {
                    return false;
                }

                _freeLastCallback = GetExportFunction<SteamFreeLastCallbackDelegate>(module, "Steam_FreeLastCallback");
                if (_freeLastCallback == null)
                {
                    return false;
                }

                _steamModule = module;
                return true;
            }
            catch
            {
                return false;
            }
        }

        private static T GetExportFunction<T>(IntPtr module, string name) where T : class
        {
            IntPtr address = Native.GetProcAddress(module, name);
            return address == IntPtr.Zero ? null : Marshal.GetDelegateForFunctionPointer(address, typeof(T)) as T;
        }

        private static bool GetCallback(out CallbackMessage message, out int call)
        {
            lock (_steamLock)
            {
                return _getCallback(_pipe, out message, out call);
            }
        }

        private static bool FreeLastCallback()
        {
            lock (_steamLock)
            {
                return _freeLastCallback(_pipe);
            }
        }

        private static void HideToTray()
        {
            ShowWindow(_consoleWindow, SW_HIDE);
            _isHidden = true;
        }

        private static void ShowFromTray()
        {
            ShowWindow(_consoleWindow, SW_SHOW);
            ShowWindow(_consoleWindow, SW_RESTORE);
            ShowWindow(_consoleWindow, SW_SHOWNORMAL);
            SetWindowPos(_consoleWindow, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
            BringWindowToTop(_consoleWindow);
            SetForegroundWindow(_consoleWindow);
            _isHidden = false;
        }

        // Делегаты
        [UnmanagedFunctionPointer(CallingConvention.ThisCall)]
        private delegate int CreateSteamPipeDelegate(IntPtr thisPtr);

        [UnmanagedFunctionPointer(CallingConvention.ThisCall)]
        private delegate int ConnectToGlobalUserDelegate(IntPtr thisPtr, int pipe);

        [UnmanagedFunctionPointer(CallingConvention.ThisCall)]
        private delegate void ReleaseUserDelegate(IntPtr thisPtr, int pipe, int user);

        [UnmanagedFunctionPointer(CallingConvention.ThisCall)]
        private delegate void ReleaseSteamPipeDelegate(IntPtr thisPtr, int pipe);
    }
}